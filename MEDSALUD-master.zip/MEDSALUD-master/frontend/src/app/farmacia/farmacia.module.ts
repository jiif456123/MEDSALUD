import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { FarmaciaRoutingModule } from './farmacia-routing.module';


@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    FarmaciaRoutingModule
  ]
})
export class FarmaciaModule { }
