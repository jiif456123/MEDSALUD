const router = require('express').Router();
//const pacienteController = require('../paciente/paciente.controller')

//router.use('/paciente', pacienteController);

module.exports = router;
