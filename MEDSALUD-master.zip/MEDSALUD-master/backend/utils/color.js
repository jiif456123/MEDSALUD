module.exports.colors = {

    cyan: `\x1b[30m%s\x1b[0m`,
    red: `\x1b[31m%s\x1b[0m`,
    green: `\x1b[32m%s\x1b[0m`,
    yellow: `\x1b[33m%s\x1b[0m`,
    navy_blue: `\x1b[34m%s\x1b[0m`,
    purple: `\x1b[35m%s\x1b[0m`,
    sky_blue: `\x1b[36m%s\x1b[0m`,
    white: `\x1b[37m%s\x1b[0m`
}