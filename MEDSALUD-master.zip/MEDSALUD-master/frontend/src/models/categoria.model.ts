export class Categoria{

    constructor(){
  
    }
    public _id: string;
    public nombre: string;
    public especialidad: string;
  }
  