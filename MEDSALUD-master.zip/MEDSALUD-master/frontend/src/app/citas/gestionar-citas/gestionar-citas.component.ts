import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-gestionar-citas',
  templateUrl: './gestionar-citas.component.html',
  styleUrls: ['./gestionar-citas.component.css']
})
export class GestionarCitasComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
