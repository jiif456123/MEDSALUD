module.exports.database = {

    url: 'mongodb+srv://jiif123:123@cluster0.wekew.mongodb.net/myFirstDatabase?retryWrites=true&w=majority',
    options: {
        user: 'jiif123',
        pass: '123',
        db: 'medsalud',
        useCreateIndex: true,
        useNewUrlParser: true,
        useFindAndModify: false,
        useUnifiedTopology: true

    }
}